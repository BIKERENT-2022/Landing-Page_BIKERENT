# Landing-Page_BIKERENT
Proyecto para IHC y Tecnologías Móviles.
Sobre el proyecto:
Se trata de un Startup que se basa en el alquiler de bicicletas, por lo cual los segmentos objetivos serían las empresas que abastecerían de este medio de transporte y clientes jóvenes y adultos de 18 años a 60 años. Lo que ofrece BIKERENT es ello, como solución al tráfico, como medio de transporte ecólogico y como alternativa de ejercicio.

Integrantes del equipo:
Deysi Johanna Campos Ruiz, Fiorella Viviana Valencia Rivera, Gustavo Emerson Bocanegra Ojeda, Saul Caleb Fuentes Marmanillo y Victor Hugo Yupanqui Aguilar.
